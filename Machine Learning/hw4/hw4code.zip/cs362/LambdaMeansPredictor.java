package cs362;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class LambdaMeansPredictor extends Predictor{

	private double lambda;
	private int iteration;
	private HashMap<Integer, FeatureVector> uk;
	private HashMap<Integer, HashMap<Integer, FeatureVector>> rik;
	
	public LambdaMeansPredictor(double lambda, int iteration){
		this.lambda = lambda;
		this.iteration = iteration;
		this.uk = new HashMap<>();
		this.rik = new HashMap<Integer, HashMap<Integer, FeatureVector>>();
	}
	@Override
	public void train(List<Instance> instances) {
		// TODO Auto-generated method stub
		// compute u1
		initializeCluster(instances);
		// Do E-step and M-step iteratively
		for (int i=0;i<iteration;++i)
        {
			rik.clear();
			Estep(instances);
			Mstep(instances);
        }
		rik.clear();
	}

	@Override
	public Label predict(Instance instance) {
		// TODO Auto-generated method stub
		int cluster = 0;
        double min = Double.MAX_VALUE;
        for (int clusterK:uk.keySet())
        {
            double distance = computeTwoNorm(instance.getFeatureVector(), uk.get(clusterK));
            if (distance<min)
            {
            	min = distance;
                cluster = clusterK;
            }
        }
        return new ClassificationLabel(cluster);
	}
	// compute prototype
	public FeatureVector computePrototype (List<Instance> instances)
    {
        FeatureVector u1 = new FeatureVector();
        // compute u1
        for(Instance instance:instances){
            FeatureVector fv = instance.getFeatureVector();
            for(int feature:fv.featureVector.keySet()){
                if(u1.featureVector.keySet().contains(feature))
                	u1.add(feature, u1.get(feature)+fv.get(feature));
                else
                	u1.add(feature, fv.get(feature));
            }
        }
        for(int feature:u1.featureVector.keySet())
        	u1.add(feature, u1.get(feature)/instances.size());
        return u1;
    }
	
	public void initializeCluster(List<Instance> instances){
		FeatureVector u1 = computePrototype(instances);
		// update lambda
        if(lambda == 0){
            double distances = 0;
            for (Instance instance:instances)
                 distances += computeTwoNorm(instance.getFeatureVector(), u1);
            lambda = distances/instances.size();
        }
        // add u1 to uk
        uk.put(uk.size(), u1);
	}
	// compute two norm
	public double computeTwoNorm(FeatureVector x, FeatureVector xprime){
		double twoNorm = 0;
        for(Integer feature : x.featureVector.keySet())
            if(xprime.featureVector.keySet().contains(feature))
                twoNorm += Math.pow(x.get(feature)-xprime.get(feature),2);
            else
                twoNorm += Math.pow(x.get(feature),2);
        for(Integer feature : xprime.featureVector.keySet())
            if(!x.featureVector.keySet().contains(feature))
                twoNorm += Math.pow(xprime.get(feature),2);
        return twoNorm;
	}
	// return ui from rik, if not exist then create a new one
	private HashMap<Integer, FeatureVector> getui ( int index )
    {
        HashMap<Integer, FeatureVector> row;
        if ( !rik.containsKey( index ) )
            row = new HashMap<Integer, FeatureVector>();
        else
            row = rik.get( index );
        return row;
    }
	public void Estep(List<Instance> instances) {
		for (int i = 0;i<instances.size();++i) {
            int cluster = 0;
            double min = Double.MAX_VALUE;
            // find minimum distance and mark the cluster
            for (int clusterK:uk.keySet()) {
                double dis = computeTwoNorm(instances.get(i).getFeatureVector(), uk.get( clusterK ) );
                if (dis<min) {
                	min = dis;
                    cluster = clusterK;
                }
            }
          
            if (min<=lambda) {
                HashMap<Integer, FeatureVector> ui = getui(i);
                ui.clear();
                ui.put(cluster, uk.get(cluster));
                rik.put(i, ui);
            }
            else {
            	// assign to a new cluster
                cluster = uk.size();
                FeatureVector prototype = instances.get(i).getFeatureVector();
                uk.put(cluster, prototype);
                HashMap<Integer, FeatureVector> ui = getui(i);
                ui.clear();   
                ui.put(cluster, prototype);
                rik.put(i, ui);
            }
        }
	}
	
	public void Mstep(List<Instance> instances) {
		// update uk for all clusters
        for (int cluster = 0;cluster<uk.size();cluster++){
            List<Instance> clusterInstances = new ArrayList<Instance>();
            for ( int i=0;i<instances.size();++i){
                HashMap<Integer, FeatureVector> row = rik.get(i);
                if(row.containsKey(cluster))
                    clusterInstances.add(instances.get(i));
            }
            uk.put(cluster, computePrototype(clusterInstances));
        }
	}
}
